//
//  AppDelegate.h
//  quartzDrawBrokenLine
//
//  Created by lsh726 on 15/11/24.
//  Copyright © 2015年 liusonghong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

