//
//  ViewController.m
//  quartzDrawBrokenLine
//
//  Created by lsh726 on 15/11/24.
//  Copyright © 2015年 liusonghong. All rights reserved.
//

#import "ViewController.h"
#import "brokenLine.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    brokenLine *line = [[brokenLine alloc]init];
    line.frame = self.view.frame;
    line.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:line];

   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
