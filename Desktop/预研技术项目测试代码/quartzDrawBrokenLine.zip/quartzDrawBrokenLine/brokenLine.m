
//
//  brokenLine.m
//  quartzDrawBrokenLine
//
//  Created by lsh726 on 15/11/24.
//  Copyright © 2015年 liusonghong. All rights reserved.
//

#import "brokenLine.h"

@implementation brokenLine



- (void) drawRect:(CGRect)rect {
    [super drawRect:rect];

    CGContextRef context =UIGraphicsGetCurrentContext();
    CGContextBeginPath(context);
    CGContextSetLineWidth(context, 2.0);
    CGContextSetStrokeColorWithColor(context, [UIColor redColor].CGColor);
    CGFloat lengths[] = {10,10}; //虚实线的值 画10个点 空10个点
    /*
     CGContextSetLineDash(CGContextRef __nullable c, CGFloat phase,
     const CGFloat * __nullable lengths, size_t count)
     parma phase 距离起始点的多少个点开始画
     
     parma count 数组长度
     */
    CGContextSetLineDash(context, 5, lengths,2);
    CGContextMoveToPoint(context, self.center.x, self.center.y);//虚线起始点
    CGContextAddLineToPoint(context, 310.0,310.0);//虚线终点
    CGContextStrokePath(context);
    CGContextClosePath(context);
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
